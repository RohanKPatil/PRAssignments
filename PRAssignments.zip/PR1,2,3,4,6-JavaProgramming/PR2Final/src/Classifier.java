import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public abstract class Classifier 
{
  public Classifier()
  {
  }
  //classify method 1 : indicates template
  //method will populate ArrayList classifyoutput of component
  public void classify(imagecomponent imgcomp, int classifymethod,int noofoutput)
  {
	  
  }
  public static void main(String[] args) throws IOException
  {
	  mainimage m = new mainimage();
	  BufferedImage image = ImageIO.read(new File("Test1.png"));
	  ArrayList<imagecomponent> comp = m.getComponents(image);
	  for(int i=0;i<comp.size();i++)
	  {
		  System.out.println("======================================================================================================================================================");
		  System.out.println("\n\n\nComponent #"+(i+1));
		  //m.printscaledcomponent(comp.get(i));
		  ArrayList<perimeterobject> perimeterlist = m.calcperimeterlist(comp.get(i), 2);
		  System.out.println("\n\nFeature Vectors:\n");
		  System.out.println("LHGSFV: "+m.calcLHGSFV(comp.get(i)));
		  System.out.println("RHGSFV: "+m.calcRHGSFV(comp.get(i)));
		  System.out.println("TVGSFV: "+m.calcTVGSFV(comp.get(i)));
		  System.out.println("BVGSFV: "+m.calcBVGSFV(comp.get(i)));
		  System.out.println("AHWFV: "+m.calcAHWFV(comp.get(i)));
		  System.out.println("AVWFV: "+m.calcAVWFV(comp.get(i)));
		  System.out.println("HCCFV: "+m.calcHCCFV(comp.get(i)));
		  System.out.println("VCCFV: "+m.calcVCCFV(comp.get(i)));
		  System.out.println("LDCCFV: "+m.calcD1CCFV(comp.get(i)));
		  System.out.println("RDCCFV: "+m.calcD2CCFV(comp.get(i)));
	  }
	   
  }
}