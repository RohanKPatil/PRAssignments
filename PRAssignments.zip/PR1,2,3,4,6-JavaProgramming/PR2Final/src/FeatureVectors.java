import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class FeatureVectors {
	static int xc=0,yc=0;
	
	public void print(imagecomponent ic)
	{
		int[][] boundary = ic.binaryarrayscaled;
		for(int i=0;i<100;i++)
		{System.out.print(i);
	       	 for(int j=0;j<100;j++)
	       	 {
	       		 System.out.print(boundary[j][i]);
	       	 }
	       	 
	       	 System.out.println();
		}
	}
	
	
	public int[][] border(imagecomponent ic)
	{
		int[][] arr = new int[ic.binaryarrayscaled[0].length][ic.binaryarrayscaled.length];
		int h=ic.binaryarrayscaled[0].length;
		int w=ic.binaryarrayscaled.length;
		int count=0;
		int b[][]=new int[h][w];
		int c[][]=new int[h][w];
		arr = ic.binaryarrayscaled;
		for(int i=0;i<h;i++){
       	 for(int j=0;j<w;j++)
       	 {  
       		 if(arr[j][i]==1)
       		 {
	   			b[j][i]=1;
	   			xc+=i;
	   			yc+=j;
	   			count++;
	   		}	
       	 }
		
       	 
       	 
       	
       	 
        }
		xc=xc/count;
      	yc=yc/count;
		 //System.out.println("XC : "+xc);
	       	//System.out.println("YC : "+yc);
		
		for(int i=1;i<h;i++)
		{
	       	 for(int j=1;j<w;j++)
	       	 {
	       		 if((b[i][j]!=b[i][j-1]) || (b[i][j]!=b[i-1][j]))
	       		 {
	       			 if(b[i][j]==1)
	       			 c[j][i]=1;
	       			 if(b[i][j-1]==1)
	       			 c[j-1][i]=1;
	       			 if(b[i-1][j]==1)
	       			 c[j][i-1]=1;
	       		 }
	       		 
	       	 }
		}
		
		
		
		//HGSFV(c);
		//VGSFV(c);
		//AHWFV(c);
		//AVWFV(c);
		//CCFV(c);
		
		return c;
	}
	
	
public String[] HGSFV(int[][] boundary){
		
		
		int hg, hr, vg, vr, hglx=0, hgly=0, hrlx=0, hrly=0, rhrlx=0, rhrly=0, rhglx=0, rhgly=0;
		String lhgsfv="",rhgsfv="";
		for(hg=0; hg<99;hg++){
			hr=hg+1;
			for(int i=1;i<100;i++){
				if(boundary[hg][i]!=boundary[hg][i-1]){
					
					hgly = hg;
					hglx = i;
				
					break;
				}
			}
			
			rhglx=0;
			for(int i=hglx+1;i<100;i++)
			{
				if((boundary[hg][i]!=boundary[hg][i-1]) && (i>rhglx))
				{
					rhgly=hg;
					rhglx=i;
				}
					
			}
			
			
			for(int i=1;i<100;i++){
				if(boundary[hr][i]!=boundary[hr][i-1]){
					
					hrly = hr;
					hrlx = i;
					
					break;
				}
				
			}
			rhrlx=0;
			for(int i=hrlx+1;i<100;i++)
			{
				if((boundary[hr][i]!=boundary[hr][i-1]) && (i>rhrlx))
				{
					rhrly=hr;
					rhrlx=i;
				}
					
			}
			if(hg!=0)
			{
			float resultl=0.0f,resultr=0.0f;
			if(hrlx==hglx){
				resultl=90.0f;
				
			}
			else{
				resultl = (float) (Math.atan(1.0f*((-hrly)-(-hgly))/(hrlx-hglx)));
				resultl = (float) (resultl * (180/3.14));
			}
			if(rhrlx==rhglx){
				
				resultr=90.0f;
			}
				
			else
			{
			resultr = (float) (Math.atan(1.0f*((-rhrly)-(-rhgly))/(rhrlx-rhglx)));
			resultr = (float) (resultr * (180/3.14));
			}
			
			
			if(resultl==0.0f)
				lhgsfv+="H";
			else if(resultl==90.0f || resultl==-90.0f)
				lhgsfv+="V";
			else if(resultl>0.0f && resultl<90.0f)
				lhgsfv+="R";
			else
				lhgsfv+="L";
			
			if(resultr==0.0f)
				rhgsfv+="H";
			else if(resultr==90.0f || resultr==-90.0f)
				rhgsfv+="V";
			else if(resultr>0.0f && resultr<90.0f)
				rhgsfv+="R";
			else
				rhgsfv+="L";
			}
		}
		//System.out.println();
		//System.out.println("LHGSFV String left  is : "+lhgsfv);
		//System.out.println("RHGFSV String right is : "+rhgsfv);
		String[] str = new String[2];
		str[0] = lhgsfv;
		str[1] = rhgsfv;
		return str;
	}

public String[] VGSFV(int[][] boundary){
	
	int vg, vr, vglx=0, vgly=0, vrlx=0, vrly=0, rvrlx=0, rvrly=0, rvglx=0, rvgly=0;
	String tvgsfv="",bvgsfv="";
	for(vg=0; vg<100;vg++){
		vr=vg+1;
		for(int i=1;i<100;i++){
			if(boundary[i][vg]!=boundary[i-1][vg]){
				
				vgly = i;
				vglx = vg;
			
				break;
			}
		}
		
		rvgly=0;
		for(int i=vgly+1;i<100;i++)
		{
			if((boundary[i][vg]!=boundary[i-1][vg]) && (i>rvgly))
			{
				rvgly=i;
				rvglx=vg;
			}
				
		}
		
		
		for(int i=1;i<100;i++){
			if(boundary[i][vr]!=boundary[i-1][vr]){
				
				vrly = i;
				vrlx = vr;
				//System.out.println("vr1="+vr);
				break;
			}
			
		}
		rvrly=0;
		for(int i=vrly+1;i<100;i++)
		{
			if((boundary[i][vr]!=boundary[i-1][vr]) && (i>rvrly))
			{
				rvrly=i;
				rvrlx=vr;
				//System.out.println("vr2="+vr);
			}
				
		}
		if(vg!=0)
		{		
		float resultt=0.0f,resultb=0.0f;
		if(vrlx==vglx){
			resultt=90.0f;
			
		}
		else{
			resultt = (float) (Math.atan(1.0f*((-vrly)-(-vgly))/(vrlx-vglx)));
			resultt = (float) (resultt * (180/3.14));
		}
		if(rvrlx==rvglx){
			resultb=90.0f;
		}
			
		else
		{
		resultb = (float) (Math.atan(1.0f*((-rvrly)-(-rvgly))/(rvrlx-rvglx)));
		resultb = (float) (resultb * (180/3.14));
		}
		
		if(resultt==0.0f)
			tvgsfv+="H";
		else if(resultt==90.0f || resultt==-90.0f)
			tvgsfv+="V";
		else if(resultt>0.0f && resultt<90.0f)
			tvgsfv+="R";
		else
			tvgsfv+="L";
		
		if(resultb==0.0f)
			bvgsfv+="H";
		else if(resultb==90.0f || resultb==-90.0f)
			bvgsfv+="V";
		else if(resultb>0.0f && resultb<90.0f)
			bvgsfv+="R";
		else
			bvgsfv+="L";
		}
	}
	
	//System.out.println("TVGSFV String left is  : "+tvgsfv);
	
	//System.out.println("BVGFSV String right is : "+bvgsfv);
	
	String[] str = new String[2];
	str[0] = tvgsfv;
	str[1] = bvgsfv;
	return str;
}
	

public String AHWFV(int[][] boundary){
		int xl=0,xr=0,yl=0,yr=0;
		double m1=0.0,m2=0.0,aw=0.0;
		String ahwfv="";
		xc=xc;
		yc=100;
		
		int h=0;
		for(h=1;h<99;h++)
		{
			for(int i=1;i<100;i++){
				if(boundary[h][i]!=boundary[h][i-1]){
					
					yl = h;
					xl = i;
				
					break;
				}
			}
			
			xr=0;
			for(int i=xl+1;i<100;i++)
			{
				if((boundary[h][i]!=boundary[h][i-1]) && (i>xr))
				{
					yr=h;
					xr=i;
				}
					
			}
			
			m1=(float)(yl-yc)/(xc-xl);
			m2=(float)(yr-yc)/(xc-xr);
			
			aw = (float) (Math.atan(1.0f*(m1-m2)/(1-(m1*m2))));
			aw = (float) (aw * (180/3.14));
			
			if(aw>=-90.0 && aw<-75.0)
				ahwfv+='A';
			else if(aw>=-75.0 && aw<-60.0)
				ahwfv+='B';
			else if(aw>=-60.0 && aw<-45.0)
				ahwfv+='C';
			else if(aw>=-45.0 && aw<-30.0)
				ahwfv+='D';
			else if(aw>=-30.0 && aw<-15.0)
				ahwfv+='E';
			else if(aw>=-15.0 && aw<0.0)
				ahwfv+='F';
			else if(aw>=0.0 && aw<15.0)
				ahwfv+='G';
			else if(aw>=15.0 && aw<30.0)
				ahwfv+='I';
			else if(aw>=30.0 && aw<45.0)
				ahwfv+='J';
			else if(aw>=45.0 && aw<60.0)
				ahwfv+='K';
			else if(aw>=60.0 && aw<75.0)
				ahwfv+='M';
			else if(aw>=75.0 && aw<90.0)
				ahwfv+='N';
			
			//System.out.println("Left "+xl+" "+yl+" Right "+xr+" "+yr);
			//System.out.println("m1 = "+m1+" m2 = "+m2+" Angle = "+aw);
			
			
			
			
		}
		//System.out.println("AHWFV String horiz is  : "+ahwfv);
		return ahwfv;
		
		
}


public String AVWFV(int[][] boundary){
	int xt=0,xb=0,yt=0,yb=0;
	double m1=0.0,m2=0.0,aw=0.0;
	String avwfv="";
	
	
	int v=0;
	for(v=1;v<99;v++)
	{
		for(int i=1;i<100;i++){
			if(boundary[i][v]!=boundary[i][v-1]){
				
				yt = i;
				xt = v;
			
				break;
			}
		}
		
		yb=0;
		for(int i=yt+1;i<100;i++)
		{
			if((boundary[i][v]!=boundary[i][v-1]) && (i>yb))
			{
				yb=i;
				xb=v;
			}
				
		}
		
		m1=(float)(yt-yc)/(xc-xt);
		m2=(float)(yb-yc)/(xc-xb);
		
		aw = (float) (Math.atan(1.0f*(m1-m2)/(1-(m1*m2))));
		aw = (float) (aw * (180/3.14));
		
		if(aw>=-90.0 && aw<-75.0)
			avwfv+='A';
		else if(aw>=-75.0 && aw<-60.0)
			avwfv+='B';
		else if(aw>=-60.0 && aw<-45.0)
			avwfv+='C';
		else if(aw>=-45.0 && aw<-30.0)
			avwfv+='D';
		else if(aw>=-30.0 && aw<-15.0)
			avwfv+='E';
		else if(aw>=-15.0 && aw<0.0)
			avwfv+='F';
		else if(aw>=0.0 && aw<15.0)
			avwfv+='G';
		else if(aw>=15.0 && aw<30.0)
			avwfv+='I';
		else if(aw>=30.0 && aw<45.0)
			avwfv+='J';
		else if(aw>=45.0 && aw<60.0)
			avwfv+='K';
		else if(aw>=60.0 && aw<75.0)
			avwfv+='M';
		else if(aw>=75.0 && aw<90.0)
			avwfv+='N';
		
	}
	//System.out.println("AVWFV String horiz is  : "+avwfv);
	return avwfv;
	
	
}
	
	
public String[] CCFV(int[][] pixels) {
	// TODO Auto-generated method stub
	byte a1=0;
	byte[] ccfvh=new byte[100];
	byte[] ccfvv=new byte[100];
	String[] str = new String[4];
	String hccfv="",vccfv="",d1ccfv="",d2ccfv="";
	for(int i=1;i<99;i++)
	{
		a1=0;
		for(int j=1;j<99;j++)
		{ 
			
			if(pixels[i][j]==1)
			a1++;
		}
		ccfvh[i]= a1;
		//System.out.println("ccfv Horizontal is"+ccfvh[i]);
		hccfv = hccfv+ccfvh[i]+",";
		
	}
	for(int i=1;i<99;i++)
	{
		a1=0;
		for(int j=1;j<99;j++)
		{ 
			
			if(pixels[j][i]==1)
			a1++;
		}
		ccfvv[i]=a1;
		//System.out.println("ccfv vertical is"+ccfvv[i]);
		vccfv = vccfv+ccfvv[i]+",";
		
	}
	int a2=0;
	int[] ccfvd1=new int [200];
	int[] ccfvd2=new int [200];
	for(int sum=1,w1=1;sum<(98*2);sum++,w1++)
	{	
	if(w1<196)
	
	{
		a2=0;
	for(int i=1;i<99;i++)
	{
		for(int j=1;j<99;j++)
		{
			if(pixels[i][j]==1)
			{
				if((i+j)==sum)
					a2++;
			}
				
		}
		
	}
	ccfvd1[w1]=a2;
	//System.out.println("diagonal left diagonal   " +ccfvd1[w1]);
	d1ccfv = d1ccfv+ccfvd1[w1]+",";
   }
   }
	int a3=0;
	for(int sub=97,w1=1,w2=97*2;sub>0;sub--,w1++,w2--)
	{	
	if((w1<196)&&(w2>0))
	
	{
		a2=0;
		a3=0;
	for(int i=1;i<99;i++)
	{
		for(int j=98;j>0;j--)
		{
			
			if(pixels[i][j]==1)
			{
				if((((i-j)==sub)&&(i>j)))
				{
					a2++;
				}
				else if((((j-i)==sub)&&(i<=j)))
				{
					a3++;
					
				}
			}
				
		}
		
	}
	ccfvd2[w1]=a2;
	ccfvd2[w2]=a3;
	
   }
   }
	
	

for(int i=1;i<98*2;i++)
{
	//System.out.println("diagonal right diagonal   " +ccfvd2[i]);
	d2ccfv = d2ccfv+ccfvd2[i]+",";
}

str[0] = hccfv;
str[1] = vccfv;
str[2] = d1ccfv;
str[3] = d2ccfv;

return str;

}

}
