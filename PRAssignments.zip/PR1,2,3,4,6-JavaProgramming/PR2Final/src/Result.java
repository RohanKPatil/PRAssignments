public class Result 
{
public String classifyresult;
public double classifyprobability;
  public Result()
  {
  }
}