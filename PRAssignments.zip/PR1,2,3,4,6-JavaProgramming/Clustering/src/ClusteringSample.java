import java.io.File;
import java.io.IOException;

import net.sf.javaml.clustering.Clusterer;
import net.sf.javaml.clustering.KMeans;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DefaultDataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;
import net.sf.javaml.tools.data.FileHandler;


public class ClusteringSample {

	public static void main(String[] args) throws IOException
	{
		/*DefaultDataset dataset = new DefaultDataset();
		double[] values = new double[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		dataset.add(new DenseInstance(values));*/
		
		
		/*dataset.add(new DenseInstance(59));
		dataset.add(new DenseInstance(101));
		dataset.add(new DenseInstance(137));
		dataset.add(new DenseInstance(62));
		dataset.add(new DenseInstance(98));
		dataset.add(new DenseInstance(191));
		dataset.add(new DenseInstance(265));
		dataset.add(new DenseInstance(312));
		dataset.add(new DenseInstance(361));
		dataset.add(new DenseInstance(155));
		dataset.add(new DenseInstance(207));*/
		
		/*Clusterer km = new KMeans();
		System.out.println("Clustering starts");
		/* Cluster the data, it will be returned as an array of data sets, with
		  * each dataset representing a cluster. */
		/*Dataset[] clusters = km.cluster(dataset);
		System.out.println("Number of clusters = "+clusters.length);
		for(int x=0;x<clusters.length;x++)
		{
			System.out.println("\n\n\n\nCluster #"+(x+1)+":");
			for(int y=0;y<clusters[x].size();y++)
			{
				System.out.println(clusters[x].get(y));
			}
		}*/		
		
		/* values of the attributes. */
        double[] value1 = new double[] { 1 };
        double[] value2 = new double[] { 4.9};
        double[] value3 = new double[] {4.7};
        double[] value4 = new double[] {7.0};
        double[] value5 = new double[] {6.3};
        double[] value6 = new double[] {10.0};

        /*
         * The simplest incarnation of the DenseInstance constructor will only
         * take a double array as argument an will create an instance with given
         * values as attributes and no class value set. For unsupervised machine
         * learning techniques this is probably the most convenient constructor.
         */
        Instance instance1 = new DenseInstance(value1,1);
        Instance instance2 = new DenseInstance(value2,1);
        Instance instance3 = new DenseInstance(value3,2);
        Instance instance4 = new DenseInstance(value4,2);
        Instance instance5 = new DenseInstance(value5,3);
        Instance instance6 = new DenseInstance(value6,3);

        System.out.println("Instance with only values set: ");
        System.out.println(instance1);
        System.out.println(instance2);
        System.out.println(instance3);
        System.out.println(instance4);
        System.out.println(instance5);
        System.out.println(instance6);
        System.out.println();
        /*
         * To create instances that have a class value set, you can use the two
         * argument constructor which takes the values and the class value as
         * parameters.
         */
        /*Instance instanceWithClassValue = new DenseInstance(values, 1);

        System.out.println("Instance with class value set to 1: ");
        System.out.println(instanceWithClassValue);
        System.out.println();*/
        DefaultDataset data = new DefaultDataset();
        data.add(instance1);
        data.add(instance2);
        data.add(instance3);
        data.add(instance4);
        data.add(instance5);
        data.add(instance6);
        //Dataset data = FileHandler.loadDataset(new File("iris.data"), 4, ",");
        
        
        Clusterer km = new KMeans();
        /*
         * Cluster the data, it will be returned as an array of data sets, with
         * each dataset representing a cluster
         */
        
        System.out.println("Clustering starts");
        Dataset[] clusters = km.cluster(data);
        System.out.println("Cluster count: " + clusters.length);
        System.out.println(clusters[0]);
        System.out.println(clusters[1]);
        System.out.println(clusters[2]);
        System.out.println(clusters[3]);

        
        

		
	}
	
}
