import java.awt.Color;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.imageio.ImageIO;

import net.sf.javaml.clustering.Clusterer;
import net.sf.javaml.clustering.KMeans;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.core.DenseInstance;
import net.sf.javaml.core.Instance;
import net.sf.javaml.core.DefaultDataset;
//import net.sf.javaml.core.SimpleInstance;
import net.sf.javaml.distance.DistanceMeasure;
import net.sf.javaml.distance.EuclideanDistance;


public class PR2 {
	static BufferedImage image;
	//Color color;
	static int pixels[][]=new int[1000][1000];
	int temp[][]=new int[1000][1000];
	int sample[][]=new int[100][100];
	int startpixel[]={-1,-1};
	static int h;
	static int w;
	static int xmin,xmax,ymin,ymax;
	int visited[][]=new int[1000][2];
	ArrayList<Integer> xcoord = new ArrayList<Integer>();
	ArrayList<Integer> ycoord = new ArrayList<Integer>();
	
	static DefaultDataset datasetdistance;
	static DefaultDataset datasetline;
	static DefaultDataset datasetheight;
	static int maxy;
	
	
	public static void main(String[] args) throws IOException
	{
		PR2 m = new PR2();
		File f = new File("Cluster.png");
		image = ImageIO.read(f);
		h = image.getHeight();
		w = image.getWidth();
		
		pixels = m.jpgtomatrix(image);
		m.componentseparation();
	}
	
	public int[][] jpgtomatrix(BufferedImage im) throws IOException
	{		
		int a[][] = new int[1000][1000];
		for(int i=0;i<im.getHeight();i++)
		{
			for(int j=0;j<im.getWidth();j++)
			{
				if(im.getRGB(j, i)==-1)
					a[i][j]=0;
				else
					a[i][j]=1;	
			}
		}
		
		
		for(int i=0;i<h;i++)
		{
			for(int j=0;j<w;j++)
				temp[i][j]=0;
		}
		
		return a;
	}
	public void componentseparation() throws IOException
	{
		ymax=90;
		maxy=90;
		int id=0;
		datasetdistance = new DefaultDataset();
		datasetline = new DefaultDataset();
		datasetheight = new DefaultDataset();
		
		while(true)
		{
			id++;
			startpixel(xmax+1,ymin);
			flood(xmin,ymin);
			System.out.println(xcoord.size());
			xmin = xcoord.get(0);
			xmax = xcoord.get((xcoord.size())-1);
			ymin = ycoord.get(0);
			ymax = ycoord.get((ycoord.size())-1);
			
			if(ymax>maxy)
				maxy=ymax;
			
			System.out.println("ymin = "+ymin+" ymax="+ymax);
			int r = ymax-ymin;
			System.out.println("ymax-ymin="+r);
			double[] ymaxyminarray = {r};
			double[] xminarray = {xmin};
			double[] yminarray = {ymin};
			
			datasetdistance.add(new DenseInstance(xminarray,id));
			datasetline.add(new DenseInstance(yminarray,id));
			datasetheight.add(new DenseInstance(ymaxyminarray,id));
			
			xcoord.clear();
			ycoord.clear();
			
			
		}	
		
		
	}
	
	public void startpixel(int sx,int sy)
	{	
			for(int j=sx;j<w;j++)
			{
				for(int i=sy;i<maxy;i++)
				{
					if(pixels[i][j]==1)
					{
						xmin=j;
						ymin=i;
						return;
					}
				}
				
			}
			
			if((maxy+100)<h)
			{
				int i = maxy;
				maxy = maxy + 100;
				startpixel(0,(i+1));
				return;
			}
			else
			{
				System.out.println("==============================================================");
				distancebased();
				System.out.println("==============================================================");
				linebased();
				System.out.println("==============================================================");
				heightbased();
				System.out.println("==============================================================");
				System.exit(0);	
			}
				
	}
	
	public void distancebased()
	{
		System.out.println("Distance based clustering starts....");
		/* Create a new instance of the KMeans algorithm, with no options
		  * specified. By default this will generate 4 clusters. */
		Clusterer km = new KMeans(3);
		/* Cluster the data, it will be returned as an array of data sets, with
		  * each dataset representing a cluster. */
		System.out.println("Clustering starts");
		System.out.println(datasetdistance.toString());
			
		
		Dataset[] clusters = km.cluster(datasetdistance);
		System.out.println("Clustering starts");
		System.out.println("Number of clusters = "+clusters.length);
		for(int x=0;x<clusters.length;x++)
		{
			System.out.println("\nCluster #"+(x+1)+":");
			System.out.println(clusters[x]);	
				
		}				
		
	}
	
	public void linebased()
	{
		System.out.println("Line based clustering starts....");
		/* Create a new instance of the KMeans algorithm, with no options
		  * specified. By default this will generate 4 clusters. */
		Clusterer km = new KMeans(3);
		/* Cluster the data, it will be returned as an array of data sets, with
		  * each dataset representing a cluster. */
		System.out.println("Clustering starts");
		System.out.println(datasetline.toString());
			
		
		Dataset[] clusters = km.cluster(datasetline);
		System.out.println("Clustering starts");
		System.out.println("Number of clusters = "+clusters.length);
		for(int x=0;x<clusters.length;x++)
		{
			System.out.println("\nCluster #"+(x+1)+":");
			System.out.println(clusters[x]);
		}
	
	}
	
	public void heightbased()
	{
		System.out.println("Height based clustering starts....");
		/* Create a new instance of the KMeans algorithm, with no options
		  * specified. By default this will generate 4 clusters. */
		Clusterer km = new KMeans(2);
		/* Cluster the data, it will be returned as an array of data sets, with
		  * each dataset representing a cluster. */
		System.out.println("Clustering starts");
		System.out.println(datasetheight.toString());
			
		
		Dataset[] clusters = km.cluster(datasetheight);
		System.out.println("Clustering starts");
		System.out.println("Number of clusters = "+clusters.length);
		for(int x=0;x<clusters.length;x++)
		{
			System.out.println("\nCluster #"+(x+1)+":");
			System.out.println(clusters[x]);
		}
	
	}

	public void flood(int x,int y)
	{
		
		if(temp[y][x]!=2 && pixels[y][x]==1)
		{
					temp[y][x]=2;
					xcoord.add(x);
					ycoord.add(y);
					flood(x+1,y);
					flood(x-1,y);
					flood(x+1,y+1);
					flood(x+1,y-1);
					flood(x-1,y+1);
					flood(x-1,y-1);
					flood(x,y+1);
					flood(x,y-1);
				
			
		}
		Collections.sort(xcoord);
		Collections.sort(ycoord);
		
	
	}
	
	public void getImageFile() throws IOException
	{
	    BufferedImage img=new BufferedImage((xmax-xmin)+1,(ymax-ymin)+1, BufferedImage.TYPE_BYTE_BINARY);;
	    for(int i=ymin,k=0; i<=ymax; i++,k++){
	        for(int j=xmin,l=0; j<=xmax; j++,l++)
	        {
	        	Color c = new Color(image.getRGB(j, i));
			    int red = (int)(c.getRed() * 0.299);
		          int green = (int)(c.getGreen() * 0.587);
		          int blue = (int)(c.getBlue() *0.114);
			    
	            Color newColor = new Color(red+green+blue,
	                    red+green+blue,red+green+blue);
	            img.setRGB(l,k,newColor.getRGB());
	        }
	       
	    }
	    
	    
	    File output1 = new File("op.png");
	    ImageIO.write(img, "png", output1);
	}

	public void scale() throws IOException
	{
		BufferedImage scaled = ImageIO.read(new File("op.png"));
		Image i = scaled.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		BufferedImage buffered = new BufferedImage(50, 50, BufferedImage.TYPE_BYTE_BINARY);
		buffered.getGraphics().drawImage(i, 0, 0 , null);
		ImageIO.write(buffered, "png", new File("scaled.png"));
	}
}
