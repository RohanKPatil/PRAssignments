import java.util.ArrayList;


public class Stringencoding 
{
	public String removeOutliers(String charencoding)
   // public static void main(String[] args)
	{
		//String charencoding = "BBBBBBCCSSSSSSSSSBBCCCSSSSSS";
		int c=1,j=0;
		char[] chars = new char[charencoding.length()];
		int[] counts = new int[charencoding.length()];
		String compressed="";
		
		for(int i=0;i<charencoding.length()-1;i++)
		{
			if(charencoding.charAt(i)==charencoding.charAt(i+1) && (i+2)!=charencoding.length() )
				c++;
			else
			{
				chars[j] = charencoding.charAt(i);
				counts[j++] = c;
				c = 1;
			}		
		}
		for(int i=0;i<j;i++)
			System.out.println(chars[i]+","+counts[i]);
		
		for(int i=0;i<j;i++)
		{
			if(counts[i]<=2 && i>=1)
			{
				if(counts[i-1]<counts[i+1])
					chars[i] = chars[i+1];
				else
					chars[i] = chars[i-1];
			}
			if(counts[0]<=2)
				chars[0] = chars[1];
		}
		
		//for(int i=0;i<j;i++)
			//System.out.print(chars[i]);
		
		for(int i=0;i<j;i++)
		{
			if(chars[i]!=chars[i+1])
			{
				compressed = compressed + chars[i];
			}		
		}
		
		System.out.println(compressed);
		return(compressed);
	}
}
