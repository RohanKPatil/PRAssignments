import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;



class Input
{
	public ArrayList<String[]> readCSV()
	{
		String csvFile = "Input.csv";
	    String line = "";
	    String cvsSplitBy = ",";
	    ArrayList<String[]> tuples = new ArrayList<String[]>();
	    try 
	    {
	       	 BufferedReader br = new BufferedReader(new FileReader(csvFile));
	       	 while ((line = br.readLine()) != null) 
	       	 {
	                // use comma as separator
	                String[] row = line.split(cvsSplitBy);	
	                tuples.add(row);
	       	 }
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    
	    return tuples;
	}
	
	public ArrayList<ArrayList<Double>> set(ArrayList<String[]> tuples)
	{
		ArrayList<ArrayList<Double>> weights = new ArrayList<ArrayList<Double>>();
		ArrayList<Double> unitweights = new ArrayList<Double>();
		String[] row;
		double num,deno=0; 
		
		for(int j=0;j<tuples.get(0).length-1;j++)
		{
			for(int i=0;i<tuples.size();i++)
			{
				row = tuples.get(i);
				num = Double.parseDouble(row[j]);
				System.out.println("num="+num);
				deno=0;
				for(int k=0;k<row.length-1;k++)
				{
					deno = deno + Double.parseDouble(row[k])*Double.parseDouble(row[k]);
				}
				System.out.println("deno="+deno);
				System.out.println("normalized weight="+num/Math.sqrt(deno));
				
				unitweights.add(num/Math.sqrt(deno));
			}
			weights.add(unitweights);
			System.out.println("------------------------------");
		}
	
		return weights;
	}
	
}

class Pattern extends Input
{
	public ArrayList<Double> set(ArrayList<String[]> tuples, String[] testpattern)
	{
		
		
		ArrayList<Double> finaloutputs = new ArrayList<Double>();
		
		ArrayList<Double> activationfunctionoutputs = new ArrayList<Double>();
		
		ArrayList<String> categories = new ArrayList<String>();
		
		for(int i=0;i<tuples.size();i++)
		{
			categories.add(tuples.get(i)[tuples.get(0).length-1]);
		}
		
		Set<String> uniqueCategories = new HashSet<String>(categories);
		System.out.println("Categories: "+uniqueCategories.toString());
		
		for(int i=0;i<tuples.size();i++)
		{
			activationfunctionoutputs.add(activationfunction(tuples.get(i), testpattern));
		}
		
		double temp=0;
		//System.out.println("#########################"+activationfunctionoutputs.size());
		
		
		ArrayList<String> category = new ArrayList<String>();
		
		for(int i=0;i<tuples.size();i++)
		{
			category.add(tuples.get(i)[categories.get(0).length()]);
		}
		
		System.out.println(category.toString());
		Iterator<String> itr = uniqueCategories.iterator();
		String str="";
		int index;
		while(itr.hasNext())
		{
			str = itr.next();
			//System.out.println("str="+str);
			temp = 0;
			for(int i=0;i<tuples.size();i++)
			{
				//System.out.println(category.contains(str));
				index = category.indexOf(str);
				if(index!=-1)
				{
					category.set(index, "#");
					temp = temp + activationfunctionoutputs.get(index);
				}
				
			}
			System.out.println("temp = "+temp);
			finaloutputs.add(temp);
		}
		
		
		
		
		for(int k=0;k<finaloutputs.size();k++)
			System.out.println(finaloutputs.get(k));
		
		return finaloutputs;
	}
	
	public double activationfunction(String[] samplepattern, String[] testpattern)
	{
		double output=0,denom=0,temp=0;
		double[] test = new double[testpattern.length];
		double[] sample = new double[samplepattern.length];
		
		for(int i=0;i<testpattern.length;i++)
		{
			denom = denom + Double.parseDouble(testpattern[i])*Double.parseDouble(testpattern[i]);
		}
		System.out.println("Denom"+denom);
		for(int i=0;i<testpattern.length;i++)
		{
			//sample[i] = Double.parseDouble(samplepattern[i]);
			test[i] = Double.parseDouble(testpattern[i]) / Math.sqrt(denom);
			System.out.println("Test[i]"+test[i]);
		}
		
		denom=0;
		
		for(int i=0;i<samplepattern.length-1;i++)
		{
			denom = denom + Double.parseDouble(samplepattern[i])*Double.parseDouble(samplepattern[i]);
		}
		
		System.out.println("Denom:"+denom);
		for(int i=0;i<samplepattern.length-1;i++)
		{
			//sample[i] = Double.parseDouble(samplepattern[i]);
			sample[i] = Double.parseDouble(samplepattern[i]) / Math.sqrt(denom);
			System.out.println("Sample[i]"+sample[i]);
		}
		
		// The formula for activation function begins here : exp(w^T.X-1)
		for(int i=0;i<sample.length-1;i++)
		{
			temp = temp + sample[i]*test[i];
		}
		//System.out.println("temp="+temp);
		output = Math.exp(temp - 1);
		System.out.println(output);
		
		return output;
	}
	
}

public class Output extends Pattern
{
	public static void main(String[] args)
	{
		Input inp = new Input();
		Pattern pat = new Pattern();
		Output out = new Output();
		ArrayList<String[]> data = inp.readCSV();
		ArrayList<ArrayList<Double>> weights = inp.set(data);
		String[] testpattern = {"11","4"};
		ArrayList<Double> output = pat.set(data, testpattern);
		System.out.println(out.findcategory(data, output));
		
	}
	
	public String findcategory(ArrayList<String[]> tuples, ArrayList<Double> outputs)
	{
		String predictedcategory = "";
		double max = Collections.max(outputs);
		int indexofmax = outputs.indexOf(max);
		System.out.println("indexofmax"+indexofmax);
		
		ArrayList<String> categories = new ArrayList<String>();
		for(int i=0;i<tuples.size();i++)
		{
			categories.add(tuples.get(i)[tuples.get(0).length-1]);
		}
		Set<String> uniqueCategories = new HashSet<String>(categories);
		System.out.println("Categories: "+uniqueCategories.toString());
		
		
		Iterator itr = uniqueCategories.iterator();
		
		for(int i=0;i<indexofmax;i++)
			itr.next();
		
		predictedcategory = (String) itr.next();
		
		System.out.println("Predicted: "+predictedcategory);
		
		return predictedcategory;
	}

}