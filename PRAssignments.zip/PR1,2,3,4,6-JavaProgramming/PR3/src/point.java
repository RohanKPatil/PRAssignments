
public class point {
	public int x;
	public int y;
	public point()
	{
	}
	public point(int i, int j)
	{
		x = i;
		y = j;
	}
}
