import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

public class Classifier
{
  public Classifier()
  {
  }
  //classify method 1 : indicates template
  //method will populate ArrayList classifyoutput of component
  public void classify(imagecomponent imgcomp, int classifymethod,int noofoutput)
  {

  }
  public static void main(String[] args) throws Exception
  {
	  mainimage m = new mainimage();
	  Classifier c = new Classifier();
	  Scanner in = new Scanner(System.in);
	  System.out.println("Enter the image file name: ");
	  String filename = in.nextLine();
	  BufferedImage image = ImageIO.read(new File(filename));
	  System.out.println("Calculating perimeter length....");
	  
	  ArrayList<imagecomponent> comp = m.getComponents(image);
	  
	  for(int i=0;i<comp.size();i++)
	  {
		  //System.out.println("======================================================================================================================================================");
		  System.out.println("Component #"+(i+1));
		  perimeterobject p = m.getboundary(comp.get(i));
		  
		  /*for(int j=0;j<p.arr[0].length;j++)
		  {
			  for(int k=0;k<p.arr.length;k++)
			  {
				  System.out.print(p.arr[k][j]);
			  }
			  System.out.println("");
		  }*/
		  
		  ArrayList<ArrayList<Double>> avg = c.avgencoding(p);
		  System.out.println("\n\n\n");
	  }

  }

  public ArrayList<ArrayList<Double>> avgencoding(perimeterobject p) throws Exception
  {
	  int lowrange,highrange;
	  double lowpercent,highpercent;
	  Scanner in = new Scanner(System.in);
	  ArrayList<ArrayList<Double>> avgangleslist = new ArrayList<ArrayList<Double>>();
	  ArrayList<Double> centralanglelist = new ArrayList<Double>();
	  ArrayList<Double> leftanglelist = new ArrayList<Double>();
	  ArrayList<Double> rightanglelist = new ArrayList<Double>();
	  //ArrayList<Double[]> percentlist = new ArrayList<Double[]>();
	  
	  
	  perimeterpoint pt = new perimeterpoint();
	  pt.perimeterpointlist = p.coords;
	  
	  //percentlist.add(new Double[]{0.5,2.0});
	  
	  System.out.print("Enter the low range (in percentage): ");
	  lowpercent = (double)Double.parseDouble(in.nextLine());
	  
	  System.out.print("Enter the high range (in percentage): ");
	  highpercent = (double)Double.parseDouble(in.nextLine());
	  System.out.println("");
	  
	  lowrange = (int)((lowpercent/100.0)*(p.coords.size()));
	  highrange = (int)((highpercent/100.0)*(p.coords.size()));

	  System.out.println("Length of perimeter: "+pt.perimeterpointlist.size()+"\n");
	  System.out.println("Low range="+lowrange+" High range="+highrange);
	  
	  avgangleslist = pt.calcavgangle(lowrange, highrange);
	  
	  centralanglelist = avgangleslist.get(0);
	  leftanglelist = avgangleslist.get(1);
	  rightanglelist = avgangleslist.get(2);
	  
	  System.out.println("*********Average angle encoding*********");
	  for(int i=0;i<centralanglelist.size();i++)
	  {
		  System.out.print("For point #"+(i+1)+": x="+pt.perimeterpointlist.get(i).x+",y="+pt.perimeterpointlist.get(i).y+"    ");
		  System.out.print("Average angle: Central="+String.format( "%.2f",centralanglelist.get(i)));
		  System.out.print(", Before="+String.format( "%.2f",leftanglelist.get(i)));
		  System.out.println(", After="+String.format( "%.2f",rightanglelist.get(i)));
	  }

	  return avgangleslist;
  }


}