import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

import javax.imageio.ImageIO;

public class Resultt 
{
  public void matchimages(BufferedImage imgop,PrintWriter fout) throws IOException
  {
	  	//BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true));

		/*BufferedImage imgA = ImageIO.read(new File("A.png"));
		BufferedImage imgB = ImageIO.read(new File("B.png"));
		BufferedImage imgC = ImageIO.read(new File("C.png"));
		BufferedImage imgD = ImageIO.read(new File("D.png"));
		BufferedImage imgE = ImageIO.read(new File("E.png"));
		BufferedImage imgF = ImageIO.read(new File("F.png"));
		BufferedImage imgG = ImageIO.read(new File("G.png"));
		BufferedImage imgH = ImageIO.read(new File("H.png"));
		BufferedImage imgI = ImageIO.read(new File("I.png"));
		BufferedImage imgJ = ImageIO.read(new File("J.png"));
		BufferedImage imgK = ImageIO.read(new File("K.png"));
		BufferedImage imgL = ImageIO.read(new File("L.png"));
		BufferedImage imgM = ImageIO.read(new File("M.png"));
		BufferedImage imgN = ImageIO.read(new File("N.png"));
		BufferedImage imgO = ImageIO.read(new File("O.png"));
		BufferedImage imgP = ImageIO.read(new File("P.png"));
		BufferedImage imgQ = ImageIO.read(new File("Q.png"));
		BufferedImage imgR = ImageIO.read(new File("R.png"));
		BufferedImage imgS = ImageIO.read(new File("S.png"));
		BufferedImage imgT = ImageIO.read(new File("T.png"));
		BufferedImage imgU = ImageIO.read(new File("U.png"));
		BufferedImage imgV = ImageIO.read(new File("V.png"));
		BufferedImage imgW = ImageIO.read(new File("W.png"));
		BufferedImage imgX = ImageIO.read(new File("X.png"));
		BufferedImage imgY = ImageIO.read(new File("Y.png"));
		BufferedImage imgZ = ImageIO.read(new File("Z.png"));*/
		
		ArrayList<int[][]> arrays = new ArrayList<int[][]>();
		ArrayList<Integer> diff = new ArrayList<Integer>();
		ArrayList<Integer> temp = new ArrayList<Integer>();
		
		int op[][]=new int[50][50];
		int A[][]=new int[50][50];
		int B[][]=new int[50][50];
		int C[][]=new int[50][50];
		int D[][]=new int[50][50];
		int E[][]=new int[50][50];
		int F[][]=new int[50][50];
		int G[][]=new int[50][50];
		int H[][]=new int[50][50];
		int I[][]=new int[50][50];
		int J[][]=new int[50][50];
		int K[][]=new int[50][50];
		int L[][]=new int[50][50];
		int M[][]=new int[50][50];
		int N[][]=new int[50][50];
		int O[][]=new int[50][50];
		int P[][]=new int[50][50];
		int Q[][]=new int[50][50];
		int R[][]=new int[50][50];
		int S[][]=new int[50][50];
		int T[][]=new int[50][50];
		int U[][]=new int[50][50];
		int V[][]=new int[50][50];
		int W[][]=new int[50][50];
		int X[][]=new int[50][50];
		int Y[][]=new int[50][50];
		int Z[][]=new int[50][50];
		
		int diffA = 0;
		//int diffB = 0;
		//int diffC = 0;
		//int diffD = 0;
		
		mainimage m = new mainimage();
		
		for(int i=1;i<=26;i++)
		{
			arrays.add(m.convImageToArray(ImageIO.read(new File(i+".png"))));
		}
		
		/*op = m.convImageToArray(imgop);
		A = m.convImageToArray(imgA);
		B = m.convImageToArray(imgB);
		C = m.convImageToArray(imgC);
		D = m.convImageToArray(imgD);
		E = m.convImageToArray(imgE);
		F = m.convImageToArray(imgF);
		G = m.convImageToArray(imgG);
		H = m.convImageToArray(imgH);
		I = m.convImageToArray(imgI);
		J = m.convImageToArray(imgJ);
		K = m.convImageToArray(imgK);
		L = m.convImageToArray(imgL);
		M = m.convImageToArray(imgM);
		N = m.convImageToArray(imgN);
		O = m.convImageToArray(imgO);
		P = m.convImageToArray(imgP);
		Q = m.convImageToArray(imgQ);
		R = m.convImageToArray(imgR);
		S = m.convImageToArray(imgS);
		T = m.convImageToArray(imgT);
		U = m.convImageToArray(imgU);
		V = m.convImageToArray(imgV);
		W = m.convImageToArray(imgW);
		X = m.convImageToArray(imgX);
		Y = m.convImageToArray(imgY);
		Z = m.convImageToArray(imgZ);*/
		
		
		
		for(int i=0;i<26;i++)
		{
			for(int j=0;j<op.length;j++)
			{
				for(int k=0;k<op[0].length;k++)
				{
					diffA = diffA + Math.abs(op[j][k] - arrays.get(1)[j][k]);
				}
			}
			diff.add(diffA);
		}
		
		//System.out.println(diff.get(1));
		
		for(int i=0;i<26;i++)
		{
			int a = diff.get(i);
			temp.add(a); 
		}
		
		/*for(int i=0;i<op.length;i++)
		{
			for(int j=0;j<op[0].length;j++)
			{
				diffA = diffA + Math.abs(op[i][j] - A[i][j]);
			}
		}
		
		for(int i=0;i<op.length;i++)
		{
			for(int j=0;j<op[0].length;j++)
			{
				diffB = diffB + Math.abs(op[i][j] - B[i][j]);
			}
		}
		
		for(int i=0;i<op.length;i++)
		{
			for(int j=0;j<op[0].length;j++)
			{
				diffC = diffC + Math.abs(op[i][j] - C[i][j]);
			}
		}
		
		for(int i=0;i<op.length;i++)
		{
			for(int j=0;j<op[0].length;j++)
			{
				diffD = diffD + Math.abs(op[i][j] - D[i][j]);
			}
		}*/
		
		/*ArrayList<Integer> diff = new ArrayList<Integer>();
		diff.add(diffA);
		diff.add(diffB);
		diff.add(diffC);
		diff.add(diffD);*/
		
		Collections.sort(diff);
		System.out.println(diff.get(0));
		
		for(int i=0;i<26;i++)
		{
			if(diff.get(0)==temp.get(i))
			{
				System.out.println("Image is alphabet number "+i+" with probability: "+(1-(diff.get(0)/2500.0)));
			}		
		}
		/*if(diff.get(0) == diffB)
		{
			System.out.println("Image is B with probability: "+(1-(diffB/2500.0)));
			fout.println("B");
		}
		else if(diff.get(0) == diffA)
		{
			System.out.println("Image is A with probability: "+(1-(diffA/2500.0)));
			fout.println("A");
		}
		else if(diff.get(0) == diffC)
		{
			System.out.println("Image is C with probability: "+(1-(diffC/2500.0)));
			fout.println("C");
		}
		else if(diff.get(0) == diffD)
		{
			System.out.println("Image is D with probability: "+(1-(diffD/2500.0)));
			fout.println("D");
		}*/
			
	}
}