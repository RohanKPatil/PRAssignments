import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.imageio.ImageIO;


public class Classifier 
{
  public static void main(String[] args) throws IOException
  {
    mainimage ma = new mainimage();
    Resulttt res = new Resulttt();
    ArrayList<BufferedImage> components = ma.getComponents(ImageIO.read(new File("Test.png")));
    PrintWriter fout = new PrintWriter("Output.txt");
    for(int i=0;i<components.size();i++)
    {
    	res.matchimages(components.get(i),fout);
    }
    fout.close();
  }
}