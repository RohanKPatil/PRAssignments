
import java.awt.Color;
import java.awt.Image;
import java.awt.image.*;
import java.io.File;
import java.io.IOException;
import java.util.*;

import javax.imageio.ImageIO;

public class mainimage 
{
String imagename; // may be filename
int height;
int width;
int colorarray[][]; // two dimensional array representing colors of pixels
int binaryarray[][]; // two dimensional array representing binary based on threshold
BufferedImage bimage;
static int h;
static int w;
static int xmin,xmax,ymin,ymax;
int temp[][];
int visited[][]=new int[1000][1000];
ArrayList<Integer> xcoord = new ArrayList<Integer>();
ArrayList<Integer> ycoord = new ArrayList<Integer>();

static int f;
  public int[][] convImageToArray(BufferedImage bi)
  {
	  int a[][] = new int[1000][1000];
		for(int i=0;i<bi.getHeight();i++)
		{
			for(int j=0;j<bi.getWidth();j++)
			{
				if(bi.getRGB(j, i)==-1)
					a[i][j]=0;
				else
					a[i][j]=1;	
			}
		}
		return a;
  }
  public BufferedImage convFileToImage(String filename) throws IOException
  {
	  return(ImageIO.read(new File(filename)));
  }
  public int[][] convFileToArray(String filename) throws IOException
  {
	  return(convImageToArray(convFileToImage(filename)));
  }
  
  public void imagetofile(BufferedImage img,String filename) throws IOException
  {
	  File output1 = new File(filename);
	  ImageIO.write(img, "png", output1);
  }
  public ArrayList<BufferedImage> getComponents(BufferedImage image) throws IOException // get arraylist of image components
  {
	  int[][] arr = convImageToArray(image);
	  int id = 0;
	  ArrayList<BufferedImage> imagecomponents = new ArrayList<BufferedImage>();
	  
	  ymax=90;
		while(true)
		{
			startpixel(xmax+1,ymin,arr);
			if(f==1)
				break;
			
			flood(xmin,ymin,arr);
			xmin = xcoord.get(0);
			xmax = xcoord.get((xcoord.size())-1);
			ymin = ycoord.get(0);
			ymax = ycoord.get((ycoord.size())-1);
			
			getImageFile(image,("op"+(id)+".png"));
			imagecomponents.add(scaleimage(ImageIO.read(new File("op"+(id)+".png"))));
			
			xcoord.clear();
			ycoord.clear();
			id++;
			
			/*for(int i=0;i<arr.length;i++)
			{
				for(int j=0;j<arr[0].length;j++)
					temp[i][j]=0;
			}
			for(int i = ymin;i<=ymax;i++)
			{
				for(int j=xmin;j<=xmax;j++)
				{
					temp[i][j] = arr[i][j];
				}
			}*/
			
			
			//imagecomponents.add(temp);
		}
		
		return imagecomponents;
			
	  
  }

		public void startpixel(int sx,int sy, int[][] arr)
		{	
			/*if(sx<h)
			{*/
			
				for(int j=sx;j<arr[0].length;j++)
				{
					for(int i=sy;i<ymax;i++)
					{
						if(arr[i][j]==1)
						{
							xmin=j;
							ymin=i;
							return;
						}
					}
					/*if(x!=-1)
						break;*/
				}
				//System.out.println(ymax);
				if((ymax+100)<arr.length)
				{
					int i = ymax;
					ymax = ymax + 100;
					startpixel(0,(i+1),arr);
					return;
				}
				else
				{
					//System.exit(0);
					f = 1;
					return;
				}
		}
		

		public void flood(int x,int y,int [][]arr)
		{
			
			if(visited[y][x]!=2 && arr[y][x]==1)
			{
				//System.out.println(y+","+x);
						visited[y][x]=2;
						xcoord.add(x);
						ycoord.add(y);
						flood(x+1,y,arr);
						flood(x-1,y,arr);
						flood(x+1,y+1,arr);
						flood(x+1,y-1,arr);
						flood(x-1,y+1,arr);
						flood(x-1,y-1,arr);
						flood(x,y+1,arr);
						flood(x,y-1,arr);
					
				
			}
			Collections.sort(xcoord);
			Collections.sort(ycoord);
			
		
		}
  
		
		
		
  public BufferedImage scaleimage (BufferedImage img)
  {
	    //BufferedImage scaled = ImageIO.read(new File("op.png"));
		Image i = img.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		BufferedImage buffered = new BufferedImage(50, 50, BufferedImage.TYPE_BYTE_BINARY);
		buffered.getGraphics().drawImage(i, 0, 0 , null);
		return buffered;
  }
  
  public void getImageFile(BufferedImage image,String filename) throws IOException
	{
	    //int ar[][]=new int[100][100];
	    BufferedImage img=new BufferedImage((xmax-xmin)+1,(ymax-ymin)+1, BufferedImage.TYPE_BYTE_BINARY);;
	    for(int i=ymin,k=0; i<=ymax; i++,k++){
	        for(int j=xmin,l=0; j<=xmax; j++,l++)
	        {
	        	Color c = new Color(image.getRGB(j, i));
			    int red = (int)(c.getRed() * 0.299);
		          int green = (int)(c.getGreen() * 0.587);
		          int blue = (int)(c.getBlue() *0.114);
			    
	            Color newColor = new Color(red+green+blue,
	                    red+green+blue,red+green+blue);
	            img.setRGB(l,k,newColor.getRGB());
	        }
	       
	    }
	    
	    
	    File output1 = new File(filename);
	    ImageIO.write(img, "png", output1);
	    
	    //System.out.println("Image created");
	}

}